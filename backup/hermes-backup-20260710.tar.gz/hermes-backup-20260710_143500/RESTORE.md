# 🚀 Hermes Agent Restore Guide

## 📋 طريقة استرجاع النسخة الاحتياطية

### 1️⃣ فك الضغط
```bash
tar xzf hermes-backup-YYYY-MM-DD.tar.gz
cd hermes-backup-*
```

### 2️⃣ استرجاع الإعدادات
```bash
# نسخ الملفات إلى مكانها الصحيح
cp files/config.yaml ~/.hermes/
cp files/.env ~/.hermes/
cp files/auth.json ~/.hermes/ 2>/dev/null

# فك المهارات
tar xzf files/skills.tar.gz -C ~/ 2>/dev/null

# فك الجلسات (اختياري)
tar xzf files/sessions.tar.gz -C ~/ 2>/dev/null
tar xzf files/state.db ~/.hermes/ 2>/dev/null
```

### 3️⃣ استرجاع Cloudflare Tunnel
```bash
mkdir -p ~/.cloudflared
tar xzf files/cloudflared.tar.gz -C ~/ 2>/dev/null
cp files/tunnel-config.yml /tmp/tunnel-config.yml 2>/dev/null
```

### 4️⃣ تشغيل الخدمات
```bash
# تشغيل السيرفر
/opt/hermes/.venv/bin/hermes serve --host 0.0.0.0 --port 9119 &

# تشغيل التونل
/tmp/cloudflared tunnel --config /tmp/tunnel-config.yml run &

# تشغيل الجيت واي
/opt/hermes/.venv/bin/hermes gateway run &
```

### 5️⃣ اختبار الاتصال
```bash
curl -s --max-time 10 "https://hermes.moflow.pro/api/status"
```
